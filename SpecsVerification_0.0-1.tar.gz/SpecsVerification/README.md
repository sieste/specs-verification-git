This is the official repository of forecast verification routines for the SPECS FP7 project.


